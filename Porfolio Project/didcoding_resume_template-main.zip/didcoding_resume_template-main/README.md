## Did Coding - Free resume template
Hi there. We have put this resume template together to help you get noticed 
when looking for your dream devloper role.

I have put a tutorial together to help you use this template with a Django project.

Check the video out here: https://www.youtube.com/watch?v=0oSsLbh_Kv4
